Chonjou Chiang A00990317 cchiang40@my.bcit.ca
Jason Chen A00920280 jchen415@my.bcit.ca

Not completed:
Nothing

Major Challenge:
SVG images not supported by android by default, had to install external library

Special Instructions:
First time loading the country detail might take a few seconds